import argparse

import cv2
import numpy as np
import torch
from os.path import isdir, join
import os
from models.models import inverse_model, forward_model
from torch.utils import data
from core.functions import *
from torch import nn, optim
from datetime import datetime
import matplotlib.pyplot as plt

'''
import matplotlib
matplotlib.rc("font",family='youyuan')
'''
from tqdm import tqdm
import warnings

random_seed = 30
torch.manual_seed(random_seed)
torch.cuda.manual_seed_all(random_seed)
np.random.seed(random_seed)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

warnings.filterwarnings('ignore')


def get_data(args, test=False):
    seismic_data = np.load(join('data', 'marmousi2_seismic_3.npy'))  # (3400,3,1201)
    seismic_data = np.delete(seismic_data, 0, axis=2)  # (3400,3,1200)
    seismic_data = seismic_data[:, :, ::4]  # (3400,3,300)

    data_vs = np.load(join('data', 'marmousi2_vs.npy'))  # (1201,3400)
    data_vp = np.load(join('data', 'marmousi2_vp.npy'))  # (1201,3400)
    data_den = np.load(join('data', 'marmousi2_rho.npy'))  # (1201,3400)

    # 初始模型
    # vs
    init_vs = cv2.GaussianBlur(data_vs, (551, 551), 0)  # (1201,3400)
    init_vs = init_vs[:, np.newaxis]  # (1201,1,3400)
    init_vs = np.swapaxes(init_vs, 0, 2)  # (3400,1,1201)
    init_vs = np.delete(init_vs, 0, axis=2)  # (3400,1,1200) ndarry
    init_vs_mean = torch.tensor(np.mean(init_vs, keepdims=True)).float()  # 均值
    init_vs_std = torch.tensor(np.std(init_vs, keepdims=True)).float()  # 方差
    init_vs = torch.tensor(init_vs).float()
    init_vs = init_vs.cuda()
    init_vs_mean = init_vs_mean.cuda()
    init_vs_std = init_vs_std.cuda()
    init_vs_normalization = Normalization(mean_val=init_vs_mean, std_val=init_vs_std)
    init_vs = init_vs_normalization.normalize(init_vs)  # (3400,1,1200)tensor
    # vp
    init_vp = cv2.GaussianBlur(data_vp, (551, 551), 0)  # (1201,3400)
    init_vp = init_vp[:, np.newaxis]  # (1201,1,3400)
    init_vp = np.swapaxes(init_vp, 0, 2)  # (3400,1,1201)
    init_vp = np.delete(init_vp, 0, axis=2)  # (3400,1,1200) ndarry
    init_vp_mean = torch.tensor(np.mean(init_vp, keepdims=True)).float()  # 均值
    init_vp_std = torch.tensor(np.std(init_vp, keepdims=True)).float()  # 方差
    init_vp = torch.tensor(init_vp).float()
    init_vp = init_vp.cuda()
    init_vp_mean = init_vp_mean.cuda()
    init_vp_std = init_vp_std.cuda()
    init_vp_normalization = Normalization(mean_val=init_vp_mean, std_val=init_vp_std)
    init_vp = init_vp_normalization.normalize(init_vp)  # (3400,1,1200)tensor
    # den
    init_den = cv2.GaussianBlur(data_den, (551, 551), 0)  # (1201,3400)
    init_den = init_den[:, np.newaxis]  # (1201,1,3400)
    init_den = np.swapaxes(init_den, 0, 2)  # (3400,1,1201)
    init_den = np.delete(init_den, 0, axis=2)  # (3400,1,1200) ndarry
    init_den_mean = torch.tensor(np.mean(init_den, keepdims=True)).float()  # 均值
    init_den_std = torch.tensor(np.std(init_den, keepdims=True)).float()  # 方差
    init_den = torch.tensor(init_den).float()
    init_den = init_den.cuda()
    init_den_mean = init_den_mean.cuda()
    init_den_std = init_den_std.cuda()
    init_den_normalization = Normalization(mean_val=init_den_mean, std_val=init_den_std)
    init_den = init_den_normalization.normalize(init_den)  # (3400,1,1200)tensor

    init_data = torch.cat([init_vs, init_vp, init_den], dim=1)  # (3400,3,1200)tensor

    # 处理地震数据

    seismic_mean = torch.tensor(np.mean(seismic_data, keepdims=True)).float()  # 地震数据的均值
    seismic_std = torch.tensor(np.std(seismic_data, keepdims=True)).float()  # 地震数据的方差
    seismic_data = torch.tensor(seismic_data).float()
    seismic_data = seismic_data.cuda()  # 讲以上的数据加载到CPU上去
    seismic_mean = seismic_mean.cuda()
    seismic_std = seismic_std.cuda()
    seismic_normalization = Normalization(mean_val=seismic_mean, std_val=seismic_std)  # 规范化
    seismic_data = seismic_normalization.normalize(seismic_data)
    # 处理vs
    data_vs = data_vs[:, np.newaxis]  # (1201,1,3400)
    data_vs = np.swapaxes(data_vs, 0, 2)  # (3400,1,1201)
    data_vs = np.delete(data_vs, 0, axis=2)  # (3400,1,1200)
    vs_mean = torch.tensor(np.mean(data_vs, keepdims=True)).float()  # 均值
    vs_std = torch.tensor(np.std(data_vs, keepdims=True)).float()  # 方差
    data_vs = torch.tensor(data_vs).float()
    data_vs = data_vs.cuda()
    vs_mean = vs_mean.cuda()
    vs_std = vs_std.cuda()
    vs_normalization = Normalization(mean_val=vs_mean, std_val=vs_std)
    data_vs = vs_normalization.normalize(data_vs)

    data_vp = data_vp[:, np.newaxis]  # (1201,1,3400)
    data_vp = np.swapaxes(data_vp, 0, 2)  # (3400,1,1201)
    data_vp = np.delete(data_vp, 0, axis=2)  # (3400,1,1200)
    vp_mean = torch.tensor(np.mean(data_vp, keepdims=True)).float()  # 均值
    vp_std = torch.tensor(np.std(data_vp, keepdims=True)).float()  # 方差
    data_vp = torch.tensor(data_vp).float()
    data_vp = data_vp.cuda()
    vp_mean = vp_mean.cuda()
    vp_std = vp_std.cuda()
    vp_normalization = Normalization(mean_val=vp_mean, std_val=vp_std)
    data_vp = vp_normalization.normalize(data_vp)

    data_den = data_den[:, np.newaxis]  # (1201,1,3400)
    data_den = np.swapaxes(data_den, 0, 2)  # (3400,1,1201)
    data_den = np.delete(data_den, 0, axis=2)  # (3400,1,1200)
    den_mean = torch.tensor(np.mean(data_den, keepdims=True)).float()  # 均值
    den_std = torch.tensor(np.std(data_den, keepdims=True)).float()  # 方差
    data_den = torch.tensor(data_den).float()
    data_den = data_den.cuda()
    den_mean = den_mean.cuda()
    den_std = den_std.cuda()
    den_normalization = Normalization(mean_val=den_mean, std_val=den_std)
    data_den = den_normalization.normalize(data_den)

    inverted_data = torch.cat([data_vs, data_vp, data_den], dim=1)  # (3400,3,1200)

    seismic_data_fill = torch.zeros(seismic_data.shape[0] + args.width - 1, seismic_data.shape[1],
                                    seismic_data.shape[2]).cuda()
    seismic_data_fill[int((args.width - 1) / 2):int((args.width - 1) / 2) + seismic_data.shape[0], :] = seismic_data
    # seismic_data_expand:( N, 1, args.width, T)
    seismic_data_expand = torch.zeros(seismic_data.shape[0], seismic_data.shape[1], args.width,
                                      seismic_data.shape[2]).cuda()
    for i in range(seismic_data.shape[0]):
        seismic_data_expand[i, :] = seismic_data_fill[i:i + args.width, :].transpose(0, 1)
    # seismic_data:(N+args.width-1, 1, args.width+1, 470)
    seismic_data = torch.cat((seismic_data_expand, seismic_data.unsqueeze(2)), dim=2)

    if not test:  # 测试的时候执行 else后的代码 训练的时候执行 if not 后面的代码
        num_samples = seismic_data.shape[0]
        indecies = np.arange(0, num_samples)
        train_indecies = indecies[(np.linspace(0, len(indecies) - 1, args.num_train_wells)).astype(int)]

        train_data = data.Subset(data.TensorDataset(seismic_data, inverted_data, init_data), train_indecies)
        train_loader = data.DataLoader(train_data, batch_size=args.batch_size, shuffle=False)

        unlabeled_loader = data.DataLoader(data.TensorDataset(seismic_data), batch_size=args.batch_size, shuffle=True)
        return train_loader, unlabeled_loader
    else:
        test_loader = data.DataLoader(data.TensorDataset(seismic_data, inverted_data, init_data),
                                      batch_size=args.batch_size, shuffle=False, drop_last=False)
        return test_loader, seismic_normalization, vs_normalization, vp_normalization, den_normalization


def get_models(args):
    if args.test_checkpoint is None:
        # inverse_net = FPN(nonlinearity=args.nonlinearity)
        inverse_net = inverse_model(nonlinearity=args.nonlinearity)
        forward_net = forward_model(nonlinearity=args.nonlinearity)
        optimizer = optim.Adam(list(inverse_net.parameters()) + list(forward_net.parameters()), amsgrad=True,
                               lr=0.005)  # 优化器
    else:
        try:
            inverse_net = torch.load("checkpoints/" + args.test_checkpoint + "_inverse")
            forward_net = torch.load("checkpoints/" + args.test_checkpoint + "_forward")
            optimizer = torch.load("checkpoints/" + args.test_checkpoint + "_optimizer")
        except FileNotFoundError:  # 先在上面的路径里面加载模型，如果没找到就在下面的路径加载，如果还是没找到就输出一句话提示出错，最后退出exit()
            try:
                inverse_net = torch.load(args.test_checkpoint + "_inverse")
                forward_net = torch.load(args.test_checkpoint + "_forward")
                # modification_net = torch.load(args.test_checkpoint + "_modification")
                optimizer = torch.load(args.test_checkpoint + "_optimizer")
            except:
                print("No checkpoint found at '{}'- Please specify the model for testing".format(args.test_checkpoint))
                exit()

    inverse_net.cuda()
    forward_net.cuda()

    return inverse_net, forward_net, optimizer


def train(args):
    train_loader, unlabeled_loader = get_data(args)
    inverse_net, forward_net, optimizer = get_models(args)
    inverse_net.train()
    criterion = nn.MSELoss()

    # make a directory to save models if it doesn't exist
    if not isdir("checkpoints"):
        os.mkdir("checkpoints")

    loss_var = []
    print("Training the model")
    for _ in tqdm(range(args.max_epoch)):
        train_loss = []
        for x, y, z in train_loader:  # x:(12,5,6,300)  y:(12,5,1200) z:(12,5,1200)
            optimizer.zero_grad()
            x_expand = x[:, :, 0:args.width]  # x_expand输入的是CNN板块中
            x = x[:, :, args.width]  # x 输入的是RNN板块中
            y_pred = inverse_net(x, x_expand) + z  # inverse_net输入两个值，返回的值就是y_pred
            x_rec = forward_net(y)

            property_loss = criterion(y_pred, y) + criterion(x_rec, x)  # 有标签数据对应属性损失
            if args.beta != 0:
                try:
                    x_u = next(unlabeled)[0]
                except:
                    unlabeled = iter(unlabeled_loader)
                    x_u = next(unlabeled)[0]

                x_u_expand = x_u[:, :, 0:args.width]
                x_u = x_u[:, :, args.width]  # 得到x_u
                y_u_pred = inverse_net(x_u, x_u_expand)
                x_u_rec = forward_net(y_u_pred)  # 得到x_u_rec

                seismic_loss = criterion(x_u_rec, x_u)  # 地震损失对应无标签数据
            else:
                seismic_loss = 0
            loss = args.alpha * property_loss + args.beta * seismic_loss  # 总损失是地震损失加上属性损失，两者的权重不同
            loss.backward()
            optimizer.step()

            train_loss.append(loss.detach().clone())

        train_loss = torch.mean(torch.tensor(train_loss))
        loss_var.append(train_loss)

    loss_var = torch.tensor(loss_var)
    loss_var = loss_var.cpu().numpy()
    # 绘图
    plt.plot(np.arange(loss_var.shape[0]), loss_var)  # 设置绘制图像的参数
    plt.title("Curve of Training Loss")  # 标题
    plt.xlabel("Epochs")  # x轴的名字
    plt.ylabel("Training Loss")  # y轴的名字
    plt.show()

    torch.save(inverse_net, "checkpoints/{}_inverse".format(args.session_name))
    torch.save(forward_net, "checkpoints/{}_forward".format(args.session_name))
    torch.save(optimizer, "checkpoints/{}_optimizer".format(args.session_name))


def test(args):
    test_loader, seismic_normalization, vs_normalization, vp_normalization, den_normalization = get_data(args,
                                                                                                         test=True)  # 获取地震数据

    if args.test_checkpoint is None:
        args.test_checkpoint = "checkpoints/{}".format(args.session_name)
    inverse_net, forward_net, _ = get_models(args)  # 获取模型
    '''
    inverse_net = torch.load("checkpoints/" + "Feb20_155650_inverse")
    forward_net = torch.load("checkpoints/" + "Feb20_155650_forward")
    '''
    criterion = nn.MSELoss(reduction="sum")
    predicted = []  # 预测波阻抗
    true_data = []  # 真实波阻抗
    true_seismic = []
    test_property_corr = []
    test_property_r2 = []
    inverse_net.eval()  # eval函数 实现各种数据类型和str之间的转换
    # forward_net.eval()
    print("\nTesting the model\n")

    with torch.no_grad():
        test_loss = []
        for x, y, z in test_loader:
            x_expand = x[:, :, 0:args.width]
            x = x[:, :, args.width]
            y_pred = inverse_net(x, x_expand) + z
            x_rec = forward_net(y)
            loss = args.alpha * (criterion(y_pred, y) / np.prod(y.shape)) + args.beta * (
                        criterion(x_rec, x) / np.prod(x.shape))
            test_loss.append(loss.item())

            corr, r2 = metrics(y_pred.detach(), y.detach())
            test_property_corr.append(corr)
            test_property_r2.append(r2)

            true_data.append(y)
            true_seismic.append(x)
            predicted.append(y_pred)

        property_corr = torch.mean(torch.cat(test_property_corr), dim=0).squeeze()
        property_r2 = torch.mean(torch.cat(test_property_r2), dim=0).squeeze()
        loss = torch.mean(torch.tensor(test_loss))  # 损失函数
        print('corr:\n', property_corr)
        print('r2:\n', property_r2)
        print('loss:\n', loss)

        predicted = torch.cat(predicted, dim=0)  # 得到预测(3400,3,1200) tensor
        true_data = torch.cat(true_data, dim=0)  # 得到真实(3400,3,1200) tensor
        true_seismic = torch.cat(true_seismic, dim=0)  # (3400,1,300) tensor

        predicted = torch.chunk(predicted, 3, dim=1)
        predicted_vs = predicted[0]  # 得到预测的vs:[3400,1,1200]
        predicted_vp = predicted[1]  # 得到预测的vp:[3400,1,1200]
        predicted_den = predicted[2]  # 得到预测的den:[3400,1,1200]

        true_data = torch.chunk(true_data, 3, dim=1)
        true_vs = true_data[0]  # [3400,1,1200]
        true_vp = true_data[1]  # [3400,1,1200]
        true_den = true_data[2]  # [3400,1,1200]

        predicted_vss = predicted_vs.cpu().numpy()
        true_vss = true_vs.cpu().numpy()
        print('vs的MSE: {:0.4f}'.format(np.sum((predicted_vss - true_vss).ravel() ** 2) / predicted_vss.size))

        predicted_vpp = predicted_vp.cpu().numpy()
        true_vpp = true_vp.cpu().numpy()
        print('vp的MSE: {:0.4f}'.format(np.sum((predicted_vpp - true_vpp).ravel() ** 2) / predicted_vpp.size))

        predicted_denn = predicted_den.cpu().numpy()
        true_denn = true_den.cpu().numpy()
        print('den的MSE: {:0.4f}'.format(np.sum((predicted_denn - true_denn).ravel() ** 2) / predicted_denn.size))

        # 规范化 （解除归一化)
        predicted_vs = vs_normalization.unnormalize(predicted_vs)
        true_vs = vs_normalization.unnormalize(true_vs)
        predicted_vp = vp_normalization.unnormalize(predicted_vp)
        true_vp = vp_normalization.unnormalize(true_vp)
        predicted_den = den_normalization.unnormalize(predicted_den)
        true_den = den_normalization.unnormalize(true_den)

        # 加载到CPU上 并转化成numpy
        predicted_vs = predicted_vs.cpu()
        true_vs = true_vs.cpu()
        predicted_vs = predicted_vs.numpy()
        true_vs = true_vs.numpy()

        predicted_vp = predicted_vp.cpu()
        true_vp = true_vp.cpu()
        predicted_vp = predicted_vp.numpy()
        true_vp = true_vp.numpy()

        predicted_den = predicted_den.cpu()
        true_den = true_den.cpu()
        predicted_den = predicted_den.numpy()
        true_den = true_den.numpy()

        init_vs = true_vs.reshape(3400, 1200)
        init_vs = cv2.GaussianBlur(init_vs, (551, 551), 0)

        init_vp = true_vp.reshape(3400, 1200)
        init_vp = cv2.GaussianBlur(init_vp, (551, 551), 0)

        init_den = true_den.reshape(3400, 1200)
        init_den = cv2.GaussianBlur(init_den, (551, 551), 0)

        np.save('aspp_vs', predicted_vs)
        np.save('aspp_vp', predicted_vp)
        np.save('aspp_den', predicted_den)

        # ---------vs------------------------------------------------------------------------------------------------------------------------------------------------------
        # 单道200
        plt.subplot(1, 1, 1)
        x1 = true_vs[1500][0]
        x2 = predicted_vs[1500][0]
        # x3 = init_vs[1500]
        plt.plot(x1, color='black', label='true vs', linewidth=1)
        plt.plot(x2, color='red', label='predicted vs', linestyle='--', linewidth=1)
        # plt.plot(x3,color='green',label='initial vs',linestyle='-',linewidth=1)
        plt.legend()
        plt.xlabel('Sampling points')
        plt.ylabel('S-velocity')
        plt.title('No.500 CDP(ASPP-GRU)')
        plt.show()

        # 真实
        fig, (ax1) = plt.subplots(1, 1, figsize=(10, 10))
        im1 = ax1.imshow(true_vs[:, 0].T, vmin=true_vs.min(), vmax=true_vs.max())  # ,cmap = 'jet')
        ax1.set_aspect(1.55)  # marmousi2 完整时：2.7  截取部分时：0.8
        # ax1.set_aspect(35 / 30)  # seam
        ax1.set_xlabel('CDP', size=14)
        ax1.set_ylabel('Sampling points', size=14)
        ax1.set_title('true vs', size=14)
        cb = plt.colorbar(im1, fraction=0.0256)
        cb.ax.tick_params(labelsize=14)
        cb.set_label('S-velocity(m/s)', size=14)
        plt.xticks(fontsize=14)
        plt.yticks(fontsize=14)
        plt.show()

        # 预测
        fig, (ax1) = plt.subplots(1, 1, figsize=(10, 10))
        im1 = ax1.imshow(predicted_vs[:, 0].T, vmin=true_vs.min(), vmax=true_vs.max())  # ,cmap = 'jet')
        ax1.set_aspect(1.55)  # marmousi2
        # ax1.set_aspect(35 / 30)  # seam
        ax1.set_xlabel('CDP', size=14)
        ax1.set_ylabel('Sampling points', size=14)
        ax1.set_title('ASPP-GRU', size=14)
        cb = plt.colorbar(im1, fraction=0.0256)
        cb.ax.tick_params(labelsize=14)
        cb.set_label('S-velocity(m/s)', size=14)
        plt.xticks(fontsize=14)
        plt.yticks(fontsize=14)
        plt.show()

        # 残差
        fig, (ax2) = plt.subplots(1, 1, figsize=(10, 10))
        im2 = ax2.imshow(abs(true_vs[:, 0].T - predicted_vs[:, 0].T), vmin=0, vmax=2000, cmap="gray")
        ax2.set_aspect(1.55)
        # ax2.set_aspect(35 / 30)
        ax2.set_xlabel('CDP', size=14)
        ax2.set_ylabel('Sampling points', size=14)
        # ax2.set_title('Predicted')
        ax2.set_title('Absolute error', size=14)
        cb = plt.colorbar(im2, fraction=0.0256)
        plt.xticks(fontsize=14)
        plt.yticks(fontsize=14)
        cb.ax.tick_params(labelsize=14)
        cb.set_label('Absolute error(m/s)', size=14)
        plt.show()

        # -------vp----------------------------------------------------------------------------------------------------------------------
        # 单道200
        plt.subplot(1, 1, 1)
        x1 = true_vp[1500][0]
        x2 = predicted_vp[1500][0]
        # x3 = init_vp[1500]
        plt.plot(x1, color='black', label='true vp', linewidth=1)
        plt.plot(x2, color='red', label='predicted vp', linestyle='--', linewidth=1)
        # plt.plot(x3,color='green',label='initial vp',linewidth=1)
        plt.legend()
        plt.xlabel('Sampling points')
        plt.ylabel('P-velocity')
        plt.title('No.500 CDP(ASPP-GRU)')
        plt.show()

        # 真实
        fig, (ax1) = plt.subplots(1, 1, figsize=(10, 10))
        im1 = ax1.imshow(true_vp[:, 0].T, vmin=true_vp.min(), vmax=true_vp.max())  # ,cmap = 'jet')
        ax1.set_aspect(1.55)  # marmousi2 完整时：2.7  截取部分时：0.8
        # ax1.set_aspect(35 / 30)  # seam
        ax1.set_xlabel('CDP', size=14)
        ax1.set_ylabel('Sampling points', size=14)
        ax1.set_title('true vp', size=14)
        cb = plt.colorbar(im1, fraction=0.0256)
        cb.ax.tick_params(labelsize=14)
        cb.set_label('P-velocity(m/s)', size=14)
        plt.xticks(fontsize=14)
        plt.yticks(fontsize=14)
        plt.show()

        # 预测
        fig, (ax1) = plt.subplots(1, 1, figsize=(10, 10))
        im1 = ax1.imshow(predicted_vp[:, 0].T, vmin=true_vp.min(), vmax=true_vp.max())  # ,cmap = 'jet')
        ax1.set_aspect(1.55)  # marmousi2
        # ax1.set_aspect(35 / 30)  # seam
        ax1.set_xlabel('CDP', size=14)
        ax1.set_ylabel('Sampling points', size=14)
        ax1.set_title('ASPP-GRU', size=14)
        cb = plt.colorbar(im1, fraction=0.0256)
        cb.ax.tick_params(labelsize=14)
        cb.set_label('P-velocity(m/s)', size=14)
        plt.xticks(fontsize=14)
        plt.yticks(fontsize=14)
        plt.show()

        # 残差
        fig, (ax2) = plt.subplots(1, 1, figsize=(10, 10))
        im2 = ax2.imshow(abs(true_vp[:, 0].T - predicted_vp[:, 0].T), vmin=0, vmax=2000, cmap="gray")
        ax2.set_aspect(1.55)
        # ax2.set_aspect(35 / 30)
        ax2.set_xlabel('CDP', size=14)
        ax2.set_ylabel('Sampling points', size=14)
        # ax2.set_title('Predicted')
        ax2.set_title('Absolute error', size=14)
        cb = plt.colorbar(im2, fraction=0.0256)
        plt.xticks(fontsize=14)
        plt.yticks(fontsize=14)
        cb.ax.tick_params(labelsize=14)
        cb.set_label('Absolute error(m/s)', size=14)
        plt.show()

        # -------den----------------------------------------------------------------------------------------------------------------------
        # 单道200
        plt.subplot(1, 1, 1)
        x1 = true_den[1500][0]
        x2 = predicted_den[1500][0]
        # x3 = init_den[1500]
        plt.plot(x1, color='black', label='true density', linewidth=1)
        plt.plot(x2, color='red', label='predicted density', linestyle='--', linewidth=1)
        # plt.plot(x3,color='green',label='initial density',linewidth=1)
        plt.legend()
        plt.xlabel('Sampling points')
        plt.ylabel('Density')
        plt.title('No.500 CDP(ASPP-GRU)')
        plt.show()

        # 真实
        fig, (ax1) = plt.subplots(1, 1, figsize=(10, 10))
        im1 = ax1.imshow(true_den[:, 0].T, vmin=true_den.min(), vmax=true_den.max())  # ,cmap = 'jet')
        ax1.set_aspect(1.55)  # marmousi2 完整时：2.7  截取部分时：0.8
        # ax1.set_aspect(35 / 30)  # seam
        ax1.set_xlabel('CDP', size=14)
        ax1.set_ylabel('Sampling points', size=14)
        ax1.set_title('true density', size=14)
        cb = plt.colorbar(im1, fraction=0.0256)
        cb.ax.tick_params(labelsize=14)
        cb.set_label('Density(g/cm^3)', size=14)
        plt.xticks(fontsize=14)
        plt.yticks(fontsize=14)
        plt.show()

        # 预测
        fig, (ax1) = plt.subplots(1, 1, figsize=(10, 10))
        im1 = ax1.imshow(predicted_den[:, 0].T, vmin=true_den.min(), vmax=true_den.max())  # ,cmap = 'jet')
        ax1.set_aspect(1.55)  # marmousi2
        # ax1.set_aspect(35 / 30)  # seam
        ax1.set_xlabel('CDP', size=14)
        ax1.set_ylabel('Sampling points', size=14)
        ax1.set_title('ASPP-GRU', size=14)
        cb = plt.colorbar(im1, fraction=0.0256)
        cb.ax.tick_params(labelsize=14)
        cb.set_label('Density(g/cm^3)', size=14)
        plt.xticks(fontsize=14)
        plt.yticks(fontsize=14)
        plt.show()

        # 残差
        fig, (ax2) = plt.subplots(1, 1, figsize=(10, 10))
        im2 = ax2.imshow(abs(true_den[:, 0].T - predicted_den[:, 0].T), vmin=0, vmax=1.0, cmap="gray")
        ax2.set_aspect(1.55)
        # ax2.set_aspect(35 / 30)
        ax2.set_xlabel('CDP', size=14)
        ax2.set_ylabel('Sampling points', size=14)
        # ax2.set_title('Predicted')
        ax2.set_title('Absolute error', size=14)
        cb = plt.colorbar(im2, fraction=0.0256)
        plt.xticks(fontsize=14)
        plt.yticks(fontsize=14)
        cb.ax.tick_params(labelsize=14)
        cb.set_label('Absolute error(g/cm^3)', size=14)
        plt.show()


if __name__ == '__main__':
    # arguments and parameters代码中所有的在arg中的参数都在这里设置
    parser = argparse.ArgumentParser()
    parser.add_argument('-width', type=int, default=5,
                        help="Number of seismic traces in expanding data to be used for training. It must be odd奇数")
    parser.add_argument('-num_train_wells', type=int, default=12,
                        help="Number of AI traces from the model to be used for training")
    parser.add_argument('-max_epoch', type=int, default=700, help="maximum number of training epochs")
    parser.add_argument('-batch_size', type=int, default=12, help="Batch size for training")
    parser.add_argument('-alpha', type=float, default=1, help="weight of property loss term")
    parser.add_argument('-beta', type=float, default=0.1, help="weight of seismic loss term")
    parser.add_argument('-index', type=int, default=480, help="plot index of the AI")
    parser.add_argument('-test_checkpoint', type=str, action="store", default=None,
                        help="path to model to test on. When this flag is used, no training is performed")
    parser.add_argument('-session_name', type=str, action="store", default=datetime.now().strftime('%b%d_%H%M%S'),
                        help="name of the session to be ised in saving the model")
    parser.add_argument('-nonlinearity', action="store", type=str, default="tanh",
                        help="Type of nonlinearity for the CNN [tanh, relu]", choices=["tanh", "relu"])
    parser.add_argument('-resolution_ratio', type=int, default=4, action="store",
                        help="resolution mismtach between seismic and AI")
    args = parser.parse_args()

    # use the following command to modify the test_checkpoint:
    # parser.set_defaults(test_checkpoint="Nov19_205735")
    # args = parser.parse_args()

    if args.test_checkpoint is not None:
        test(args)
    else:
        train(args)
        test(args)
