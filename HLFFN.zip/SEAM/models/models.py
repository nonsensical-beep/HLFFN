import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from torch.nn.utils import weight_norm


class ASPPConv(nn.Sequential):
    def __init__(self, in_channels, out_channels, dilation):
        modules = [
            nn.Conv2d(in_channels, out_channels,kernel_size=3, padding=dilation, dilation=dilation, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU()
        ]
        super(ASPPConv, self).__init__(*modules)

class ASPPPooling(nn.Sequential):
    def __init__(self, in_channels, out_channels):
        super(ASPPPooling, self).__init__(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU())

    def forward(self, x):
        size = x.shape[-2:]
        for mod in self:
            x = mod(x)
        return F.interpolate(x, size=size, mode='bilinear', align_corners=False)

class ASPP(nn.Module):
    def __init__(self, in_channels, atrous_rates, out_channels):
        super(ASPP, self).__init__()
        modules = []
        '''
        modules.append(nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU()))
        '''
        rates = tuple(atrous_rates)
        for rate in rates:
            modules.append(ASPPConv(in_channels, out_channels, rate))

        modules.append(ASPPPooling(in_channels, out_channels))

        self.convs = nn.ModuleList(modules)

        self.project = nn.Sequential(
            nn.Conv2d(len(self.convs) * out_channels, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Dropout(0.5))

    def forward(self, x):
        res = []
        for conv in self.convs:
            res.append(conv(x))
        res = torch.cat(res, dim=1)
        return self.project(res)

class BasicConv(nn.Module):
    def __init__(self,in_planes,out_planes,kernel_size,stride,padding,dilation=1, groups=1,relu=True,bn=True,bias=False): #stride=1,padding=0,dilation=1, groups=1
        super(BasicConv, self).__init__()
        self.out_channels = out_planes
        self.conv = nn.Conv2d(in_planes,
                              out_planes,
                              kernel_size=kernel_size,
                              stride=stride,
                              padding=padding,
                              dilation=dilation,
                              groups=groups,
                              bias=bias,)
        self.bn = (nn.BatchNorm2d(out_planes, eps=1e-5, momentum=0.01, affine=True)
            if bn
            else None
                   )
        self.relu = nn.ReLU() if relu else None

    def forward(self, x):
        x = self.conv(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.relu is not None:
            x = self.relu(x)
        return x

class ZPool(nn.Module):
    def forward(self, x):
        return torch.cat( (torch.max(x,1)[0].unsqueeze(1), torch.mean(x,1).unsqueeze(1)), dim=1)

class AttentionGate(nn.Module):
    def __init__(self):
        super(AttentionGate, self).__init__()
        kernel_size = 3
        self.compress = ZPool()
        self.conv = BasicConv(2, 1, kernel_size, stride=1, padding=(kernel_size-1) // 2, relu=False)
    def forward(self, x): #x:60,20,701

        x_compress = self.compress(x) #x_compress:1,2,20,701
        x_out = self.conv(x_compress)  #x_out:1,1,20,701
        scale = torch.sigmoid_(x_out) # scale:1,1,20,701
        return x * scale

class TripletAttention1d(nn.Module):
    def __init__(self, no_spatial=False):
        super(TripletAttention1d, self).__init__()
        self.cw = AttentionGate()
        self.hc = AttentionGate()
        self.no_spatial=no_spatial
        if not no_spatial:
            self.hw = AttentionGate()
    def forward(self, x):
        #分支1 ,交换第一维和第二维 x:20,60,701 → x_perm1:60,20,701
        x_perm1 = x.permute(1,0,2).contiguous() #permute :将tensor的维度换位  torch.contiguous()方法首先拷贝了一份张量在内存中的地址，然后将地址按照形状改变后的张量的语义进行排列
        x_perm1 = torch.unsqueeze(x_perm1,dim=0)
        x_out1 = self.cw(x_perm1) #x_out1 : 1,60,20,701
        x_out1 = torch.squeeze(x_out1,dim=0)
        x_out11 = x_out1.permute(1,0,2).contiguous()#x_out11: 20,60 ,701
        #分支2，交换第一维和第三维
        x_perm2 = x.permute(2,1,0).contiguous()
        x_perm2 = torch.unsqueeze(x_perm2,dim=0)
        x_out2 = self.hc(x_perm2)
        x_out2 = torch.squeeze(x_out2, dim=0)
        x_out21 = x_out2.permute(2,1,0).contiguous()

        #分支3
        if not self.no_spatial: #no_spatial = False
            x = torch.unsqueeze(x,dim=0)
            x_out = self.hw(x) #x_out:1,20,60,701
            x_out = torch.squeeze(x_out, dim=0)
            x_out = 1/3 * (x_out + x_out11 + x_out21)
        else:
            x_out = 1/2 * (x_out11 + x_out21)
        return x_out

class TripletAttention2d(nn.Module):
    def __init__(self, no_spatial=False):
        super(TripletAttention2d, self).__init__()
        self.cw = AttentionGate()
        self.hc = AttentionGate()
        self.no_spatial=no_spatial
        if not no_spatial:
            self.hw = AttentionGate()
    def forward(self, x):
        #分支1 ,交换第一维和第二维 x:20,60,701 → x_perm1:60,20,701
        x_perm1 = x.permute(0,2,1,3).contiguous()
        #x_perm1 = x.permute(2, 0, 1, 3).contiguous()
 #permute :将tensor的维度换位  torch.contiguous()方法首先拷贝了一份张量在内存中的地址，然后将地址按照形状改变后的张量的语义进行排列
        x_out1 = self.cw(x_perm1) #x_out1 : 1,60,20,701
        x_out11 = x_out1.permute(0,2,1,3).contiguous()#x_out11: 20,60 ,701

        #分支2，交换第一维和第三维
        x_perm2 = x.permute(0,3,2,1).contiguous()
        #x_perm2 = x.permute(2, 3, 0, 1).contiguous()
        x_out2 = self.hc(x_perm2)
        x_out21 = x_out2.permute(0,3,2,1).contiguous()

        #分支3
        if not self.no_spatial: #no_spatial = False
            #x = x.permute(2,1,0,3).contiguous()
            x_out = self.hw(x) #x_out:1,20,60,701
            x_out = 1/3 * (x_out + x_out11 + x_out21)
        else:
            x_out = 1/2 * (x_out11 + x_out21)
        return x_out


class inverse_model(nn.Module):
    def __init__(self, resolution_ratio=4, nonlinearity="tanh"):
        super(inverse_model, self).__init__()
        self.resolution_ratio = resolution_ratio
        self.activation = nn.ReLU() if nonlinearity == "relu" else nn.Tanh()#激活函数

        self.cnn1 = nn.Conv2d(in_channels=3, out_channels=8, kernel_size=(1, 5), padding=(0, 2))
        self.groupnorm1 = nn.GroupNorm(num_groups=1, num_channels=8)
        self.pooling1 = nn.MaxPool2d(kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        self.groupnorm2 = nn.GroupNorm(num_groups=1, num_channels=8)

        self.cnn2 = nn.Conv2d(in_channels=1, out_channels=8, kernel_size=(1, 5), padding=(0, 6), dilation=(1, 3))
        self.groupnorm3 = nn.GroupNorm(num_groups=1, num_channels=8)
        self.pooling2 = nn.MaxPool2d(kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        self.groupnorm4 = nn.GroupNorm(num_groups=1, num_channels=8)

        self.cnn3 = nn.Conv2d(in_channels=1, out_channels=8, kernel_size=(1, 5), padding=(0, 12), dilation=(1, 6))
        self.groupnorm5 = nn.GroupNorm(num_groups=1, num_channels=8)
        self.pooling3 = nn.MaxPool2d(kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        self.groupnorm6 = nn.GroupNorm(num_groups=1, num_channels=8)

        # self.cnn4 = nn.Conv2d(in_channels=16, out_channels=16, kernel_size=(3, 3), padding=(0, 1))
        # self.groupnorm7 = nn.GroupNorm(num_groups=1, num_channels=16)
        self.cnn5 = nn.Conv2d(in_channels=16, out_channels=16, kernel_size=(3, 3), padding=(0, 1))
        self.groupnorm8 = nn.GroupNorm(num_groups=1, num_channels=16)
        self.cnn6 = nn.Conv2d(in_channels=16, out_channels=16, kernel_size=(1, 1))
        self.groupnorm9 = nn.GroupNorm(num_groups=1, num_channels=16)

        self.gru = nn.GRU(input_size=3, hidden_size=8, num_layers=3, batch_first=True, bidirectional=True)


        self.cnnt1 = nn.ConvTranspose1d(in_channels=16, out_channels=8, stride=2, kernel_size=4, padding=1)
        self.groupnorm10 = nn.GroupNorm(num_groups=1, num_channels=8)
        self.cnnt2 = nn.ConvTranspose1d(in_channels=8, out_channels=8, stride=2, kernel_size=4, padding=1)
        self.groupnorm11 = nn.GroupNorm(num_groups=1, num_channels=8)

        self.gru_out = nn.GRU(input_size=16, hidden_size=8, num_layers=1, batch_first=True, bidirectional=True)
        self.out = nn.Linear(in_features=16, out_features=3)



        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose1d):
                nn.init.xavier_uniform_(m.weight.data)
                m.bias.data.zero_()
            elif isinstance(m, nn.GroupNorm):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.bias.data.zero_()

        self.triplet1d = TripletAttention1d()
        self.triplet2d = TripletAttention2d()
        self.aspp = ASPP(in_channels=3, atrous_rates=( 3,6,12), out_channels=8)
        self.erf = ERF(3,8)
        self.eacb = EACB(in_channels=3, out_channels=8)
        self.ieacb = IEACB(in_channels=3, out_channels=8)

        self.tcn = TemporalConvNet2d(3, [6, 12, 24, 8], kernel_size=(9, 3), dropout=0.1)  # [6, 12, 24, 8]

        self.hff = HFF_block(ch_1=8, ch_2=8, r_2=3, ch_int=32, ch_out=32, drop_rate=0.)

    def forward(self,x,x_expand):

        #aa = self.triplet2d(x_expand)

        cnn_out1 = self.cnn1(x_expand)
        cnn_out1 = self.groupnorm1(cnn_out1)
        cnn_out1 = self.pooling1(cnn_out1)
        cnn_out1 = self.groupnorm2(cnn_out1)

        # TCN低频信息提取模块
        x_expand1 = x_expand.permute(0, 1, 3, 2)  # (12, 3, 300, 5)
        x_expand1 = self.tcn(x_expand1)  # (12, 8, 300, 5)
        x_expand1 = x_expand1.permute(0, 1, 3, 2)  # (12, 8, 5, 300)
        # IEACB低频信息提取模块
        # out1 = self.aspp(x_expand)
        #out1 = self.erf(x_expand)
        out1 = self.eacb(x_expand)
        #out1 = self.ieacb(x_expand)  # (12,8,5,300)

        #out1 = self.hff(l=out1, g=x_expand1, f=cnn_out1)
        out1 = torch.cat((x_expand1, out1),dim=1)

       
        cnn_out = self.activation(out1)
        cnn_out = self.cnn5(cnn_out)
        cnn_out = self.groupnorm8(cnn_out)

        cnn_out = self.activation(cnn_out)
        cnn_out = self.cnn6(cnn_out)
        #cnn_out = self.triplet2d(cnn_out)
        cnn_out = self.groupnorm9(cnn_out)
        cnn_out = self.activation(cnn_out)

        cnn_out = cnn_out.squeeze(dim=2)


        x = cnn_out #+ rnn_out

        tmp_x = x.transpose(-1, -2)
        x, _ = self.gru_out(tmp_x)

        x = self.out(x)
        x = x.transpose(-1, -2)
        return x




class forward_model(nn.Module):
    def __init__(self,resolution_ratio=4, nonlinearity="tanh"):
        super(forward_model, self).__init__()
        self.resolution_ratio = resolution_ratio
        self.activation = nn.ReLU() if nonlinearity == "relu" else nn.Tanh()
        self.cnn1 = nn.Conv1d(in_channels=3, out_channels=4, kernel_size=9, padding=4)
        self.cnn2 = nn.Conv1d(in_channels=4, out_channels=4,kernel_size=7, padding=3)
        self.cnn3 = nn.Conv1d(in_channels=4, out_channels=3,kernel_size=3, padding=1)


    def forward(self, x):

        x = self.cnn1(x)
        x = self.activation(x)
        x = self.cnn2(x)
        x = self.activation(x)
        x = self.cnn3(x)
        return x

class CropLayer(nn.Module):
    #   E.g., (-1, 0) means this layer should crop the first and last rows of the feature map. And (0, -1) crops the first and last columns
    def __init__(self, crop_set):
        super(CropLayer, self).__init__()
        self.rows_to_crop = - crop_set[0]
        self.cols_to_crop = - crop_set[1]
        assert self.rows_to_crop >= 0
        assert self.cols_to_crop >= 0

    def forward(self, input):
        return input[:, :, self.rows_to_crop:-self.rows_to_crop, self.cols_to_crop:-self.cols_to_crop]
class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        return x
class asyConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, dilation=1, groups=1, padding_mode='zeros', deploy=False):
        super(asyConv, self).__init__()
        self.deploy = deploy
        if deploy:
            self.fused_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=(kernel_size,kernel_size), stride=stride,
                                      padding=padding, dilation=dilation, groups=groups, bias=True, padding_mode=padding_mode)
            self.initialize()
        else:
            self.square_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels,
                                         kernel_size=(kernel_size, kernel_size), stride=stride,
                                         padding=padding, dilation=dilation, groups=groups, bias=False,
                                         padding_mode=padding_mode)
            self.square_bn = nn.BatchNorm2d(num_features=out_channels)

            center_offset_from_origin_border = padding - kernel_size // 2
            ver_pad_or_crop = (center_offset_from_origin_border + 1, center_offset_from_origin_border)
            hor_pad_or_crop = (center_offset_from_origin_border, center_offset_from_origin_border + 1)
            if center_offset_from_origin_border >= 0:
                self.ver_conv_crop_layer = nn.Identity()
                ver_conv_padding = ver_pad_or_crop
                self.hor_conv_crop_layer = nn.Identity()
                hor_conv_padding = hor_pad_or_crop
            else:
                self.ver_conv_crop_layer = CropLayer(crop_set=ver_pad_or_crop)
                ver_conv_padding = (0, 0)
                self.hor_conv_crop_layer = CropLayer(crop_set=hor_pad_or_crop)
                hor_conv_padding = (0, 0)
            self.ver_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=(3, 1),
                                      stride=stride,
                                      padding=ver_conv_padding, dilation=dilation, groups=groups, bias=False,
                                      padding_mode=padding_mode)

            self.hor_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=(1, 3),
                                      stride=stride,
                                      padding=hor_conv_padding, dilation=dilation, groups=groups, bias=False,
                                      padding_mode=padding_mode)
            self.ver_bn = nn.BatchNorm2d(num_features=out_channels)
            self.hor_bn = nn.BatchNorm2d(num_features=out_channels)


    def forward(self, input):
        if self.deploy:
            return self.fused_conv(input)
        else:
            square_outputs = self.square_conv(input)
            square_outputs = self.square_bn(square_outputs)
            vertical_outputs = self.ver_conv_crop_layer(input)
            vertical_outputs = self.ver_conv(vertical_outputs)
            vertical_outputs = self.ver_bn(vertical_outputs)
            horizontal_outputs = self.hor_conv_crop_layer(input)
            horizontal_outputs = self.hor_conv(horizontal_outputs)
            horizontal_outputs = self.hor_bn(horizontal_outputs)
            return square_outputs + vertical_outputs + horizontal_outputs
class ERF(nn.Module):
    def __init__(self, x, y):
        super(ERF, self).__init__()
        #asy不对称卷积
        self.asyConv = asyConv(in_channels=x, out_channels=y, kernel_size=3, stride=1, padding=1, dilation=1, groups=1, padding_mode='zeros', deploy=False)
        self.oriConv = nn.Conv2d(x, y, kernel_size=3, stride=1, padding=1)
        #膨胀卷积
        self.atrConv = nn.Sequential(
            nn.Conv2d(x, y, kernel_size=3, dilation=3, padding=3, stride=1), nn.BatchNorm2d(y), nn.PReLU()
        )
        self.conv2d = nn.Conv2d(y*2, y, kernel_size=3, stride=1, padding=1)
        self.bn2d = nn.BatchNorm2d(y)
        self.res = BasicConv2d(x, y, 1)

    def forward(self, f):
        p2 = self.asyConv(f)
        p3 = self.atrConv(f)
        p  = torch.cat((p2, p3), 1)
        p  = F.relu(self.bn2d(self.conv2d(p)), inplace=True)

        return p


class EACB(nn.Module):
    def __init__(self, in_channels, out_channels, padding_mode='zeros'):
        super(EACB, self).__init__()

        #正方形卷积
        self.square_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels,
                                     kernel_size=(3, 3), stride=1,
                                     padding=1, bias=False, padding_mode=padding_mode)
        #横向卷积
        self.ver_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels,
                                  kernel_size=(3, 1), stride=1,
                                  padding=(1, 0), bias=False, padding_mode=padding_mode)
        #纵向卷积
        self.hor_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels,
                                  kernel_size=(1, 3), stride=1,
                                  padding=(0, 1), bias=False, padding_mode=padding_mode)
        #斜角1到9的卷积
        self.diag19_conv = Conv_19(in_channels=in_channels, out_channels=out_channels)

        #斜角3到7的卷积
        self.diag37_conv = Conv_37(in_channels=in_channels, out_channels=out_channels)

        #膨胀卷积
        #self.atrConv = nn.Sequential(nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=3, dilation=3, padding=3, stride=1), nn.BatchNorm2d(out_channels), nn.PReLU())


    def forward(self, input):
        square_outputs = self.square_conv(input)
        vertical_outputs = self.ver_conv(input)
        horizontal_outputs = self.hor_conv(input)
        diag19_outputs = self.diag19_conv(input)
        diag37_outputs = self.diag37_conv(input)
        #atrconv_output = self.atrConv(input)

        return square_outputs + vertical_outputs + horizontal_outputs + diag19_outputs + diag37_outputs
class IEACB(nn.Module):
    def __init__(self, in_channels, out_channels, padding_mode='zeros'):
        super(IEACB, self).__init__()

        #膨胀卷积
        self.square_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels,
                                     kernel_size=(3, 3), stride=1,dilation=2,
                                     padding=2, bias=False, padding_mode=padding_mode)
        #横向卷积
        self.ver_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels,
                                  kernel_size=(3, 1), stride=1,
                                  padding=(1, 0), bias=False, padding_mode=padding_mode)
        #纵向卷积
        self.hor_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels,
                                  kernel_size=(1, 3), stride=1,
                                  padding=(0, 1), bias=False, padding_mode=padding_mode)
        #斜角1到9的卷积
        self.diag19_conv = Conv_19(in_channels=in_channels, out_channels=out_channels)

        #斜角3到7的卷积
        self.diag37_conv = Conv_37(in_channels=in_channels, out_channels=out_channels)

        #膨胀卷积
        #self.atrConv = nn.Sequential(nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=3, dilation=3, padding=3, stride=1), nn.BatchNorm2d(out_channels), nn.PReLU())


    def forward(self, input):
        square_outputs = self.square_conv(input)
        vertical_outputs = self.ver_conv(input)
        horizontal_outputs = self.hor_conv(input)
        diag19_outputs = self.diag19_conv(input)
        diag37_outputs = self.diag37_conv(input)
        #atrconv_output = self.atrConv(input)

        return square_outputs + vertical_outputs + horizontal_outputs + diag19_outputs + diag37_outputs #+ atrconv_output


class Conv_19(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Conv_19, self).__init__()
        self.mask = nn.Parameter(torch.Tensor(get_mask_19(in_channels, out_channels)), requires_grad=False)
        self.weight = nn.Parameter(torch.Tensor(out_channels, in_channels, 3, 3), requires_grad=True)
        self.weight.data.mul_(self.mask.data)

    def forward(self, x):
        weight = torch.mul(self.weight, self.mask)
        x = torch.nn.functional.conv2d(x, weight, bias=None, stride=1, padding=1, groups=1)
        return x

def get_mask_19(in_channels, out_channels, kernel_size=3):
    mask = np.zeros((out_channels, in_channels, 3, 3))
    for c in range(kernel_size):
        mask[:, :, c, c] = 1.
    return mask

class Conv_37(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Conv_37, self).__init__()
        self.mask = nn.Parameter(torch.Tensor(get_mask_37(in_channels, out_channels)), requires_grad=False)
        self.weight = nn.Parameter(torch.Tensor(out_channels, in_channels, 3, 3), requires_grad=True)
        self.weight.data.mul_(self.mask.data)

    def forward(self, x):
        weight = torch.mul(self.weight, self.mask)
        x = torch.nn.functional.conv2d(x, weight, bias=None, stride=1, padding=1, groups=1)
        return x

def get_mask_37(in_channels, out_channels, kernel_size=3):
    mask = np.zeros((out_channels, in_channels, 3, 3))
    for c in range(kernel_size):
        mask[:, :, 2-c, c] = 1.
    return mask


#TCN
class Chomp2d(nn.Module):
    def __init__(self, chomp_size):
        super(Chomp2d, self).__init__()
        self.chomp_size = chomp_size

    def forward(self, x):
        return x[:, :, :-self.chomp_size, :].contiguous()

class TemporalBlock2d(nn.Module):
    def __init__(self, n_inputs, n_outputs, kernel_size, stride, dilation, padding, dropout=0.2):
        super(TemporalBlock2d, self).__init__()
        self.conv1 = weight_norm(nn.Conv2d(n_inputs, n_outputs, kernel_size,
                                           stride=stride, padding=padding, dilation=dilation, bias=True))
        self.chomp1 = Chomp2d(padding[0])
        self.relu1 = nn.ReLU()
        self.dropout1 = nn.Dropout(dropout)

        self.conv2 = weight_norm(nn.Conv2d(n_outputs, n_outputs, kernel_size,
                                           stride=stride, padding=padding, dilation=dilation, bias=True))
        self.chomp2 = Chomp2d(padding[0])
        self.relu2 = nn.ReLU()
        self.dropout2 = nn.Dropout(dropout)

#         self.net = nn.Sequential(self.conv1, self.chomp1, self.relu1, self.dropout1,
#                                  self.conv2, self.chomp2, self.relu2, self.dropout2)
        self.net = nn.Sequential(self.conv1, self.relu1, self.dropout1,
                                 self.conv2, self.relu2, self.dropout2)
        self.downsample = nn.Conv2d(n_inputs, n_outputs, (1, 1), bias=True) if n_inputs != n_outputs else None
        self.relu = nn.ReLU()
        self.init_weights()

    def init_weights(self):
        self.conv1.weight.data.normal_(0, 0.01)
        self.conv2.weight.data.normal_(0, 0.01)
        if self.downsample is not None:
            self.downsample.weight.data.normal_(0, 0.01)

    def forward(self, x):
        out = self.net(x)
        res = x if self.downsample is None else self.downsample(x)
        return self.relu(out + res)

class TemporalConvNet2d(nn.Module):
    def __init__(self, num_inputs, num_channels, kernel_size=(9, 3), dropout=0.2):
        super(TemporalConvNet2d, self).__init__()
        layers = []
        num_levels = len(num_channels)
        for i in range(num_levels):
            dilation_size = 2 ** i
            in_channels = num_inputs if i == 0 else num_channels[i - 1]
            out_channels = num_channels[i]
            layers += [TemporalBlock2d(in_channels, out_channels, kernel_size, stride=1, dilation=(dilation_size, 1),
                                       padding=(int((kernel_size[0]-1)/2 * dilation_size), 1), dropout=dropout)]

        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)


# Hierachical Feature Fusion Block
class HFF_block(nn.Module):
    def __init__(self, ch_1, ch_2, r_2, ch_int, ch_out, drop_rate=0.):
        super(HFF_block, self).__init__()
        self.maxpool=nn.AdaptiveMaxPool2d(1) #自适应最大池化
        self.avgpool=nn.AdaptiveAvgPool2d(1) #自适应均值池化
        self.se=nn.Sequential(
            nn.Conv2d(ch_2, ch_2 // r_2, 1,bias=False),
            nn.ReLU(),
            nn.Conv2d(ch_2 // r_2, ch_2, 1,bias=False)
        )
        self.sigmoid = nn.Sigmoid()
        self.spatial = Conv(2, 1, 7, bn=True, relu=False, bias=False)
        self.W_l = Conv(ch_1, ch_int, 1, bn=True, relu=False)
        self.W_g = Conv(ch_2, ch_int, 1, bn=True, relu=False)
        self.Avg = nn.AvgPool2d(1, stride=1)
        self.Updim = Conv(8, ch_int, 1, bn=True, relu=True)
        self.norm1 = LayerNorm(ch_int * 3, eps=1e-6, data_format="channels_first")
        self.norm2 = LayerNorm(ch_int * 2, eps=1e-6, data_format="channels_first")
        self.norm3 = LayerNorm(ch_1 + ch_2 + ch_int, eps=1e-6, data_format="channels_first")
        self.W3 = Conv(ch_int * 3, ch_int, 1, bn=True, relu=False)
        self.W = Conv(ch_int * 2, ch_int, 1, bn=True, relu=False)

        self.gelu = nn.GELU()

        self.residual = IRMLP(ch_1 + ch_2 + ch_int, ch_out)
        self.drop_path = DropPath(drop_rate) if drop_rate > 0. else nn.Identity()

    def forward(self, l, g, f):

        W_local = self.W_l(l)  #(12,32,5,300) # local feature from Local Feature Block
        W_global = self.W_g(g)  #(12,32,5,300) # global feature from Global Feature Block
        if f is not None:
            W_f = self.Updim(f) #(12,32,5,300)
            W_f = self.Avg(W_f)
            shortcut = W_f
            X_f = torch.cat([W_f, W_local, W_global], 1)
            X_f = self.norm1(X_f)
            X_f = self.W3(X_f)
            X_f = self.gelu(X_f)
        else:
            shortcut = 0
            X_f = torch.cat([W_local, W_global], 1)
            X_f = self.norm2(X_f)
            X_f = self.W(X_f)
            X_f = self.gelu(X_f)

        # spatial attention for ConvNeXt branch
        l_jump = l
        max_result, _ = torch.max(l, dim=1, keepdim=True)
        avg_result = torch.mean(l, dim=1, keepdim=True)
        result = torch.cat([max_result, avg_result], 1)
        l = self.spatial(result)
        l = self.sigmoid(l) * l_jump

        # channel attetion for transformer branch
        g_jump = g
        max_result=self.maxpool(g)
        avg_result=self.avgpool(g)
        max_out=self.se(max_result)
        avg_out=self.se(avg_result)
        g = self.sigmoid(max_out+avg_out) * g_jump

        fuse = torch.cat([g, l, X_f], 1)
        fuse = self.norm3(fuse)
        fuse = self.residual(fuse)
        fuse = shortcut + self.drop_path(fuse)
        return fuse

class Conv(nn.Module):
    def __init__(self, inp_dim, out_dim, kernel_size=3, stride=1, bn=False, relu=True, bias=True, group=1):
        super(Conv, self).__init__()
        self.inp_dim = inp_dim
        self.conv = nn.Conv2d(inp_dim, out_dim, kernel_size, stride, padding=(kernel_size-1)//2, bias=bias)
        self.relu = None
        self.bn = None
        if relu:
            self.relu = nn.ReLU(inplace=True)
        if bn:
            self.bn = nn.BatchNorm2d(out_dim)

    def forward(self, x):
        assert x.size()[1] == self.inp_dim, "{} {}".format(x.size()[1], self.inp_dim)
        x = self.conv(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.relu is not None:
            x = self.relu(x)
        return x

class IRMLP(nn.Module):
    def __init__(self, inp_dim, out_dim):
        super(IRMLP, self).__init__()
        self.conv1 = Conv(inp_dim, inp_dim, 3, relu=False, bias=False, group=inp_dim)
        self.conv2 = Conv(inp_dim, inp_dim * 4, 1, relu=False, bias=False)
        self.conv3 = Conv(inp_dim * 4, out_dim, 1, relu=False, bias=False, bn=True)
        self.gelu = nn.GELU()
        self.bn1 = nn.BatchNorm2d(inp_dim)

    def forward(self, x):

        residual = x
        out = self.conv1(x)
        out = self.gelu(out)
        out += residual

        out = self.bn1(out)
        out = self.conv2(out)
        out = self.gelu(out)
        out = self.conv3(out)

        return out

class LayerNorm(nn.Module):
    r""" LayerNorm that supports two data formats: channels_last (default) or channels_first.
    The ordering of the dimensions in the inputs. channels_last corresponds to inputs with
    shape (batch_size, height, width, channels) while channels_first corresponds to inputs
    with shape (batch_size, channels, height, width).
    """

    def __init__(self, normalized_shape, eps=1e-6, data_format="channels_last"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape), requires_grad=True)
        self.bias = nn.Parameter(torch.zeros(normalized_shape), requires_grad=True)
        self.eps = eps
        self.data_format = data_format
        if self.data_format not in ["channels_last", "channels_first"]:
            raise ValueError(f"not support data format '{self.data_format}'")
        self.normalized_shape = (normalized_shape,)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.data_format == "channels_last":
            return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            # [batch_size, channels, height, width]
            mean = x.mean(1, keepdim=True)
            var = (x - mean).pow(2).mean(1, keepdim=True)
            x = (x - mean) / torch.sqrt(var + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x

def drop_path_f(x, drop_prob: float = 0., training: bool = False):
    """Drop paths (Stochastic Depth) per sample (when applied in main path of residual blocks).

    This is the same as the DropConnect impl I created for EfficientNet, etc networks, however,
    the original name is misleading as 'Drop Connect' is a different form of dropout in a separate paper...
    See discussion: https://github.com/tensorflow/tpu/issues/494#issuecomment-532968956 ... I've opted for
    changing the layer and argument names to 'drop path' rather than mix DropConnect as a layer name and use
    'survival rate' as the argument.

    """
    if drop_prob == 0. or not training:
        return x
    keep_prob = 1 - drop_prob
    shape = (x.shape[0],) + (1,) * (x.ndim - 1)  # work with diff dim tensors, not just 2D ConvNets
    random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
    random_tensor.floor_()  # binarize
    output = x.div(keep_prob) * random_tensor
    return output

class DropPath(nn.Module):
    """Drop paths (Stochastic Depth) per sample  (when applied in main path of residual blocks).
    """
    def __init__(self, drop_prob=None):
        super(DropPath, self).__init__()
        self.drop_prob = drop_prob

    def forward(self, x):
        return drop_path_f(x, self.drop_prob, self.training)